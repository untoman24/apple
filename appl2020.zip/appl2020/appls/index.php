<?php

header ('location: assets/includes/login.php');

?>
