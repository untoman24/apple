<?php
include("lang.zb.php");

$detect_origin =$direct.$IPS;
$detect_bot = $active . $IPS.",". $detect_origin ;
?>
<?php FuckRobots(); ?>